<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NetworksController extends Controller
{
    //
}
