Please post support requests and questions in the DataTables forums at https://datatables.net/forums. Support requests posted here will be closed. This allows all questions to be located in a single, searchable, location.

When you post your question in the DataTables forums, please ensure that you include a link to the page showing the issue so it can be debugged.
